import UIKit

//Задача 1

/*
 1. Мишин Анатолий.
 2. Из увлечений - игра на пианино, чтение литературы, люблю смотреть старые аниме-сериалы.
 3. Опыта работы с другими языками нет, изучаю SWIFT с августа 2022.
 4. Инструменты: ЭВМ MacBook Air M1, Xcode, GitHub.
 5. Коммерческого опыта работы в программировании нет.
 6. Кандидат юридических наук (Политехнический университет СПб).
 */



// Задача 2

let myName:String = "Anatoliy"
let mySurname:String = "Mishin"
var myAge:Int = 27
let mySex:String = "male"
var myBestCity: String = "Anchorage"
let myExpMacOs: Bool = true
var myFirstSalary:Int = 100000
var myVacationYear:Int = 30
var myPrefColor:String = "Grey"



//Задача 3

var salaryMidIos = 150000
var salaryJunIos = 80000
var slaryMidAndroid = 140000

// условия задачи

var newSalaryMidIos: Double = Double(salaryMidIos) * 1.2
var newSalaryJunIos = salaryJunIos + 20000
//так как зарплата мидл айос инжинера целая, то дальше уберу дробную часть
print("По прошествии 6 месяцев работы, зарплаты сотрудников изменились следующим образом:")
print("Зарплата Mid iOS:", Int(newSalaryMidIos), "рублей")
print("Зарплата Jun iOS:", newSalaryJunIos, "рублей")
print("Зарплата Mid Andriod: без изменений")


