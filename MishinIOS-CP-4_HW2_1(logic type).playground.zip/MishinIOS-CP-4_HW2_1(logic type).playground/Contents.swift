import UIKit

/* Модуль 2. Домашняя работа 3. "Логические типы и т.д."
 Учащийся: Мишин Анатолий Вадимович.
 Группа: iOS-CP-4
 Дата выполнения и загрузки в NL: 16.12.2022 */



// Задача №1.


/* Дополнительные условности задачи:
 1. В каждом месяце 8 выходных;
 2. В январе дополнительно 8 выходных;
 3. В феврале дополнительно 1 выходной;
 4. В марте дополнительно 1 выходной;
 5. в мае дополнительно 1 выходной;
 6. В июне дополнительно 1 выходной;
 7. В ноябре дополнительно 1 выходной. */
  
// Объявляю 12 констант месяцев с явной типизацией:
let januaryMonth: String = "Январь"
let februaryMonth: String = "Февраль"
let marchMonth: String = "Март"
let aprilMonth: String = "Апрель"
let mayMonth: String = "Май"
let juneMonth: String = "Июнь"
let julyMonth: String = "Июль"
let augustMonth: String = "Август"
let septemberMonth: String = "Сентябрь"
let octoberMonth: String = "Октябрь"
let novemberMonth: String = "Ноябрь"
let decemberMonth: String = "Декабрь"

// Создам переменную selectedMonth c явной типизацией (Xcode ругается в констркукции, что необходимо инициализировать эту переменную), присвою ей значение Апрель:
var selectedMonth:String = "Апрель"

/* БОНУСОМ объявлю массив типа String с месяцами в году (сами же напрашиваются!)чтобы посчитать их и потренироваться, все остальное по ТЗ :) */
var monthInYear: [String] = [januaryMonth, februaryMonth, marchMonth, aprilMonth, mayMonth, juneMonth, julyMonth, augustMonth, septemberMonth, octoberMonth, novemberMonth, decemberMonth]
print("В году \(monthInYear.count) месяцев и в каждом месяце разное количество рабочих дней. \nВ выбранном вами месяце (\(selectedMonth)) следующее количество рабочих дней:")

// Создам конструкицю if которая будет проверять selectedMonth и выводить все в консоль:
if selectedMonth == januaryMonth {
    print("В январе \(31-16) рабочих дней дней.")
} else if selectedMonth == februaryMonth {
    print("В феврале \(28-9) рабочих дней.")
} else if selectedMonth == marchMonth {
    print("В марте \(31-9) рабочих дней.")
} else if selectedMonth == aprilMonth {
    print("В апреле \(30-18) рабочих дней.")
} else if selectedMonth == mayMonth {
    print("В мае \(31-9) рабочих дней.")
} else if selectedMonth == juneMonth {
    print("В июне \(30-9) рабочих дней.")
} else if selectedMonth == julyMonth {
    print("В июле \(31-8) рабочих дней.")
} else if selectedMonth == augustMonth {
    print("В августе \(31-8) рабочих дней.")
} else if selectedMonth == septemberMonth {
    print("В сентябре \(30-8) рабочих дней.")
} else if selectedMonth == octoberMonth {
    print("В октябре \(31-8) рабочих дней.")
} else if selectedMonth == novemberMonth {
    print("В ноябре \(30-9) рабочих дней.")
} else if selectedMonth == decemberMonth {
    print("В декабре \(30-8) рабочих дней.")
}

// Отделим задачи, чтобы в консоли не было путаницы:
print("\n\n")



// Задача №2.


// Для красоты текста в консоли:
print("Пожалуйста, выберете месяц, чтобы узнать количество рабочих дней:")

// Аналогично прошлому заданию, только используется конструкция switch:
switch selectedMonth {
case januaryMonth:
    print("В январе \(31-16) рабочих дней дней.")
case februaryMonth:
    print("В феврале \(28-9) рабочих дней.")
case marchMonth:
    print("В марте \(31-9) рабочих дней.")
case aprilMonth:
    print("В апреле \(30-18) рабочих дней.")
case mayMonth:
    print("В мае \(31-9) рабочих дней.")
case juneMonth:
    print("В июне \(30-9) рабочих дней.")
case julyMonth:
    print("В июле \(31-8) рабочих дней.")
case augustMonth:
    print("В августе \(31-8) рабочих дней.")
case septemberMonth:
    print("В сентябре \(30-8) рабочих дней.")
case octoberMonth:
    print("В октябре \(31-8) рабочих дней.")
case novemberMonth:
    print("В ноябре \(30-9) рабочих дней.")
case decemberMonth:
    print("В декабре \(30-8) рабочих дней.")
default:
    print("Месяц не выбран.")
}

// Отделим задачи, чтобы в консоли не было путаницы:
print("\n\n")



// Задача №3.


// Под условия задачи сделаю две явных константы:
let text1: String = "это рабочий день."
let text2: String = "это выходной день."

// Создам переменную типа Bool:
var isHoliday = true

// Создам конструкцию с тернарным оператором:
var isToday = isHoliday ? text2 : text1
print("Согласно календарю, \(isToday)")

// Отделим задачи, чтобы в консоли не было путаницы:
print("\n\n")



// Задача №4* (со звездочкой).


// НА ЭТОМ ЗАДАНИИ У МЕНЯ ПУКНУЛА ГОЛОВА! Но вроде Xcode комиллирует...

// Создам перечисление по всем месяцам и внутри него свойство description:
enum MounthInRow {
    case januaryMonth
    case februaryMonth
    case marchMonth
    case aprilMonth
    case mayMonth
    case juneMonth
    case julyMonth
    case augustMonth
    case septemberMonth
    case octoberMonth
    case novemberMonth
    case decemberMonth
   
    var description: String {
        switch self{
        case .januaryMonth: return "Январь"
        case .februaryMonth: return "Февраль"
        case .marchMonth: return "Март"
        case .aprilMonth: return "Апрель"
        case .mayMonth: return "Май"
        case .juneMonth: return "Июнь"
        case .julyMonth: return "Июль"
        case .augustMonth: return "Август"
        case .septemberMonth: return "Сентябрь"
        case .octoberMonth: return "Октябрь"
        case .novemberMonth: return "Ноябрь"
        case .decemberMonth: return "Декабрь"
        }
        }
}
    
    print(MounthInRow.aprilMonth.description)

 


