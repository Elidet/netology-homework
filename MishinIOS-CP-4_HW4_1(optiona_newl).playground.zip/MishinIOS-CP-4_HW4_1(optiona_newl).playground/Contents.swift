import UIKit

/* Модуль 2. Домашняя работа 4. "Опциональные типы и преобразование"
 Учащийся: Мишин Анатолий Вадимович.
 Группа: iOS-CP-4
 Дата выполнения и загрузки в NL: 18.12.2022 */




//ДОРАБОТКА.первое задание правильное, не трогал. Второе изменил в соответствии с ревью






print("________Задача №1. (1.1)________")


// Создам 3 опциональные строковые переменные с условиями задачи
var someString1: String? = "10"
var someString2: String? = "100"
var someString3: String? = nil

// Попробуем вывести в консоль условно-рандомныt строковые значения используя оператор nil-объединения
print(someString1 ?? "11")
print(someString2 ?? "111")
print(someString3 ?? "1111") // Ага!!! Вижу, что someSrting3 - nil, как и инициализирвал выше

// По условию задачи присвою третьей переменной значение, возьму "1000"
someString3 = "1000"

// Теперь снова попробую вывести в консоль третью переменную с условно-рандомным значением используя оператор nil-объединения
print(someString3 ?? "9876")
// Ага! Вывел в консоль новое значение третьей переменной!

print("________1.2________")








//(1.2)

/* создам 5 строковых констант, часть содержит только цифры, другие еще и буквы. Также по усовию задачи надо сложить суммы констант, сделаю под это отдельную переменную и присвою для начала целочисленное значение 0
 */
let const1: String = "12345"
let const2: String = "HNY2023"
let const3: String = "100200"
let const4: String = "a1b2c3"
let const5: String = "18122022"

var sumOfConst: Int = 0







/* Необходимо найти сумму констант, приведя к целочисленным значениям. Попробую сначала проверить на nil и вывести в консоль что могу, без краша программы */

if Int(const1) != nil {
    print(const1)
} else {
    print("Error, const1 is nil")
}

if Int(const2) != nil {
    print(const2)
} else {
    print("Error, const2 is nil")
}
    
if Int(const3) != nil {
        print(const3)
} else {
    print("Error, const3 is nil")
}
        
if Int(const4) != nil {
            print(const4)
} else {
    print("Error, const4 is nil")
}

if Int(const5) != nil {
        print(const5)
} else {
    print("Error,const5 is nil")
}

/* Увидел в консоли значения, которые есть и те, которые nil. Имея в распоряжении значения констант, их можно сложить, используя неявное извлечение */
sumOfConst = Int(const1)! + Int(const3)! + Int(const5)!
print(sumOfConst)

print("__________________")




// Теперь по условию задачи использую optional binding. Создам отдельную переменную и присвою значение 0

var resOfString: Int = 0

if var resOfString1 = Int(const1) {
    resOfString1 = resOfString1 + resOfString
    print(resOfString1)
} else {
    print ("Error, const1 is nil")
}

if var resOfString2 = Int(const2) {
    resOfString2 = resOfString2 + resOfString
    print(resOfString2)
} else {
    print ("Error, const2 is nil")
}

if var resOfString3 = Int(const3) {
    resOfString3 = resOfString3 + resOfString
    print(resOfString3)
} else {
    print ("Error, const3 is nil")
}

if var resOfString4 = Int(const4) {
    resOfString4 = resOfString4 + resOfString
    print(resOfString4)
} else {
    print ("Error, const4 is nil")
}

if var resOfString5 = Int(const5) {
    resOfString5 = resOfString5 + resOfString
    print(resOfString5)
} else {
    print ("Error, const5 is nil")
}




/* Мы увидели, какие константы из условия задачи являются определенными значениями при преобразовании в Int, а какие nil. Теперь можно сложить! */
var sumConstOptBind = Int(const1)! + Int(const3)! + Int(const5)!
print(sumConstOptBind)





print("________Задача 2________")


// Новое решение


let outsideTemp: Optional<Int> = Int("-15")
var message: String = ""

if let temperature: Int = outsideTemp {
    if temperature >= 0 {
        message = "За окном полжительная температура"
        print(message)
    } else if temperature <= 0 {
        message = "За окном отрицательная температура"
        print(message)
    } else if temperature >= 10 {
        message = "За окном теплее 10 градусов"
        print(message)
    } else if temperature < -10 {
        message = "Одевайтесь тепло, на улице мороз!"
        print(message)
    } else if outsideTemp == nil {
        message = "Error, its nil"
        print(message)
    }
}
        
/*

// Создам опц константу и присвоим значение с типом string и преобразованием в Int. Далее по условиям задачи. Сначала прверю на nil

let optConst: Optional<Int> = Int("-15")

if optConst != nil {
    print("!nil and value: \(Int(optConst!))")
} else {
print("Error, its nil")
}



// Для закрепления проверю вторым способом!
var optConstValue = 0
if var optConst1: Int = optConst {
    optConst1 = optConst1 + optConstValue
    print("!nil and value: \(optConst1)")
} else {
    print("Error, its nil")
}






// Проеврив на nil, со значением константы могу смело работать!
 
 if optConst! > 0 {
    print("Температура за окном больше нуля")
}

if optConst! < 0 {
    print("Темература за окном меньше нуля")
}

if optConst! < -10 {
    print("Одевайтесь тепло, за окном меньше -10")
}

if optConst! > 10 {
    print("Можно надеть тонкую ветровку, за окном больше 10")
}

if optConst == nil {
    print("Error, its nil")
}
*/
