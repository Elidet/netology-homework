import UIKit

/* Учащийся: Мишин Анатолий
 Группа: iOS-CP-4
 Дата выполнения: 25.12.2022
*/


// Задача №1

var userInfo = (film: "Трое из Белвилля", number: 3, food: "Рамен с якитотки") // a
let (film, number, food) = userInfo
var userInfo2 = (film: "Шрек", number: 228, food: "Пюре с котлеткой") // b
var userIngo3 = userInfo // c, c = a
userInfo = userInfo2 // a = b
userInfo2 = userIngo3 // b = c
print(userInfo)
print(userInfo2)


// Задача №2

var studentInfo = ["studentName": ["studentDicipline": "Информатика", "studentHasGrade": 5]]
// по условиям задачи 3 элемента, но и по тем же условиям 2 элемента в словере в словаре. Оставляю 2, как указано
print(type(of: studentInfo))


// Задача №3 + №4*

typealias Chessman = [String: (alpha: Character, num: Int)?]

var chessmans: Chessman = ["Белая королева": (alpha: "A", num: 5),
                           "Белый ферзь": nil,
                           "Черный ферзь": (alpha: "C", num: 3)]

// Вариант 1

for chess in chessmans {
    if let coordinates = chess.value {
        print("\(chess.key) на \(coordinates.alpha)\(coordinates.num)")
    } else {
        print("\(chess.key) is dead")
    }
}

// Вариант 2

for (key, value) in chessmans {
    if let coordinates = value {
        print("\(key) на \(coordinates.alpha)\(coordinates.num)")
    } else {
        print("\(key) is dead")
    }
}

// Вариант 3, который предлагается на сайте - залупа, т.к. при распаковке ключа он опционален и без 0,5 не разобраться

if let key = chessmans["Белая королева"], let coordinates = key {
    print("Белая королева на \(coordinates.alpha)\(coordinates.num)")
} else {
    print("Белая королева мертв(-а)")
}

