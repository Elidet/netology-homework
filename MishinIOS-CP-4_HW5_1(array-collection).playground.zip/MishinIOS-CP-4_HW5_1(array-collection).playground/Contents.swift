import UIKit
/*
 Учащийся: Анатолий Мишин
 Группа: iOS-CP-4
 Дата выполнения: 31.12.2022
*/


// Задача №1

let males = ["Anatoliy", "Danil"]
let females = ["Anna", "Irina", "Sveta"]
var students = females

for male in males {
    students.insert(male, at: students.startIndex)
}
print(students)
print("-------------------")


// Задача №2

students = students.sorted()
print(students)
// Или сразу в принт без присваивания print(students.sorted())
// Можно сразу students.sort()
print("-------------------")


// Задача №3ци

let raiting = [-3, 4, 9, -10, -2, 7, 1, 3, 3, 10, -5]
let sortrdRaiting = raiting.sorted()
let positiveRaiting = sortrdRaiting.filter( {$0 > 0})
print("Positive Raitng: \(positiveRaiting)")
print("-------------------")


// Задача №4*

let numbers = [1, 2, 3, 4, 7, 8, 15]

for (index, value) in numbers.enumerated() {
    for (sameIndex, sameValue) in numbers.enumerated() where value + sameValue == 6 && index < sameIndex {
        print("Первый индекс \(index) и второй индекс \(sameIndex). Сумма значений этих индексов равна 6.")
    }
}
